import asyncio
import logging
from datetime import datetime

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message

from config import BOT_TOKEN, ADMIN_IDS
from database import (
    init_db,
    add_or_update_user,
    get_user_by_telegram_id,
    start_work_session,
    end_work_session,
    format_seconds,
    get_user_stats,
    get_user_stats_by_period,
    get_admin_daily_stats,
    get_admin_all_workers_stats,
    set_hourly_rate,
    set_role,
)
from keyboards import get_main_keyboard


dp = Dispatcher()


def is_admin_user(telegram_id: int) -> bool:
    return telegram_id in ADMIN_IDS


@dp.message(CommandStart())
async def cmd_start(message: Message):
    telegram_id = message.from_user.id
    full_name = message.from_user.full_name
    username = message.from_user.username

    is_admin = is_admin_user(telegram_id)

    add_or_update_user(
        telegram_id=telegram_id,
        full_name=full_name,
        username=username,
        is_admin=is_admin
    )

    user = get_user_by_telegram_id(telegram_id)

    text = (
        f"Привет, {full_name}!\n\n"
        f"Это бот учёта рабочего времени.\n"
        f"Ваша роль: {'Администратор' if user['role'] == 'admin' else 'Сотрудник'}\n"
        f"Ставка в час: {user['hourly_rate']}"
    )

    await message.answer(
        text,
        reply_markup=get_main_keyboard(is_admin=user["role"] == "admin")
    )


@dp.message(F.text == "Начало работы")
async def start_work(message: Message):
    user = get_user_by_telegram_id(message.from_user.id)
    if not user:
        await message.answer("Сначала нажми /start")
        return

    success = start_work_session(user["id"])

    if success:
        now_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        await message.answer(f"Рабочая смена начата.\nВремя начала: {now_str}")
    else:
        await message.answer("У вас уже есть активная смена. Сначала завершите её.")


@dp.message(F.text == "Конец работы")
async def finish_work(message: Message):
    user = get_user_by_telegram_id(message.from_user.id)
    if not user:
        await message.answer("Сначала нажми /start")
        return

    result = end_work_session(user["id"])

    if result is None:
        await message.answer("У вас нет активной смены.")
        return

    worked_seconds = result["worked_seconds"]
    start_time = datetime.fromisoformat(result["start_time"])
    end_time = datetime.fromisoformat(result["end_time"])

    start_time_str = start_time.strftime("%d.%m.%Y %H:%M:%S")
    end_time_str = end_time.strftime("%d.%m.%Y %H:%M:%S")

    worked_hours = worked_seconds / 3600
    amount = worked_hours * user["hourly_rate"]

    await message.answer(
        "Рабочая смена завершена.\n"
        f"Время начала: {start_time_str}\n"
        f"Время окончания: {end_time_str}\n"
        f"Отработано: {format_seconds(worked_seconds)}\n"
        f"Сумма за смену: {round(amount, 2)}"
    )


@dp.message(F.text == "Моя статистика")
async def my_stats(message: Message):
    stats = get_user_stats(message.from_user.id)
    if not stats:
        await message.answer("Статистика не найдена.")
        return

    await message.answer(
        "Ваша статистика:\n\n"
        f"Сотрудник: {stats['full_name']}\n"
        f"Количество смен: {stats['total_sessions']}\n"
        f"Всего времени: {stats['formatted_time']}\n"
        f"Ставка в час: {stats['hourly_rate']}\n"
        f"Общая сумма: {stats['total_amount']}"
    )


@dp.message(F.text == "Подсчёт за период")
async def period_help(message: Message):
    await message.answer(
        "Отправьте период в формате:\n"
        "2026-03-01 2026-03-31\n\n"
        "То есть:\n"
        "дата_начала дата_конца"
    )


@dp.message(F.text.regexp(r"^\d{4}-\d{2}-\d{2}\s+\d{4}-\d{2}-\d{2}$"))
async def calculate_period_stats(message: Message):
    try:
        start_date, end_date = message.text.strip().split()
        stats = get_user_stats_by_period(message.from_user.id, start_date, end_date)

        if not stats:
            await message.answer("Не удалось получить статистику за период.")
            return

        await message.answer(
            "Статистика за период:\n\n"
            f"Сотрудник: {stats['full_name']}\n"
            f"Период: {stats['start_date']} — {stats['end_date']}\n"
            f"Количество смен: {stats['total_sessions']}\n"
            f"Всего времени: {stats['formatted_time']}\n"
            f"Ставка в час: {stats['hourly_rate']}\n"
            f"Сумма: {stats['total_amount']}"
        )
    except Exception:
        await message.answer("Ошибка формата. Пример:\n2026-03-01 2026-03-31")


@dp.message(F.text == "Статистика сотрудников")
async def admin_workers_stats(message: Message):
    if not is_admin_user(message.from_user.id):
        await message.answer("У вас нет доступа к этой функции.")
        return

    stats = get_admin_all_workers_stats()
    if not stats:
        await message.answer("Нет данных.")
        return

    lines = ["Статистика сотрудников:\n"]
    for row in stats:
        total_hours = format_seconds(row["total_seconds"] or 0)
        amount = round(((row["total_seconds"] or 0) / 3600) * (row["hourly_rate"] or 0), 2)

        lines.append(
            f"{row['full_name']}\n"
            f"ID: {row['telegram_id']}\n"
            f"Смен: {row['sessions_count']}\n"
            f"Время: {total_hours}\n"
            f"Ставка: {row['hourly_rate']}\n"
            f"Сумма: {amount}\n"
        )

    text = "\n".join(lines)

    for i in range(0, len(text), 4000):
        await message.answer(text[i:i + 4000])


@dp.message(F.text == "Статистика по дням")
async def admin_daily_stats(message: Message):
    if not is_admin_user(message.from_user.id):
        await message.answer("У вас нет доступа к этой функции.")
        return

    stats = get_admin_daily_stats()
    if not stats:
        await message.answer("Нет данных.")
        return

    lines = ["Статистика по дням:\n"]
    for row in stats:
        lines.append(
            f"Дата: {row['work_day']}\n"
            f"Сотрудник: {row['full_name']}\n"
            f"Смен: {row['sessions_count']}\n"
            f"Время: {format_seconds(row['total_seconds'] or 0)}\n"
        )

    text = "\n".join(lines)

    for i in range(0, len(text), 4000):
        await message.answer(text[i:i + 4000])


@dp.message(Command("setrate"))
async def cmd_set_rate(message: Message):
    if not is_admin_user(message.from_user.id):
        await message.answer("У вас нет доступа к этой команде.")
        return

    parts = message.text.split()
    if len(parts) != 3:
        await message.answer("Использование:\n/setrate TELEGRAM_ID СТАВКА\nПример:\n/setrate 123456789 500")
        return

    try:
        telegram_id = int(parts[1])
        rate = float(parts[2])
    except ValueError:
        await message.answer("Ошибка в данных. Проверь ID и ставку.")
        return

    success = set_hourly_rate(telegram_id, rate)
    if success:
        await message.answer(f"Ставка {rate} успешно установлена для пользователя {telegram_id}")
    else:
        await message.answer("Пользователь не найден.")


@dp.message(Command("setrole"))
async def cmd_set_role(message: Message):
    if not is_admin_user(message.from_user.id):
        await message.answer("У вас нет доступа к этой команде.")
        return

    parts = message.text.split()
    if len(parts) != 3:
        await message.answer("Использование:\n/setrole TELEGRAM_ID employee/admin")
        return

    try:
        telegram_id = int(parts[1])
        role = parts[2].strip().lower()
    except ValueError:
        await message.answer("Ошибка в данных.")
        return

    success = set_role(telegram_id, role)
    if success:
        await message.answer(f"Роль {role} установлена для пользователя {telegram_id}")
    else:
        await message.answer("Не удалось изменить роль.")


@dp.message(Command("myid"))
async def cmd_my_id(message: Message):
    await message.answer(f"Ваш Telegram ID: {message.from_user.id}")


@dp.message()
async def unknown_message(message: Message):
    await message.answer("Не понял команду. Используй кнопки меню или /start")


async def main():
    logging.basicConfig(level=logging.INFO)
    init_db()

    bot = Bot(token=BOT_TOKEN)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())