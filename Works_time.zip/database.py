import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any


BASE_DIR = Path(__file__).resolve().parent
DB_NAME = BASE_DIR / "work_time.db"


def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        username TEXT,
        role TEXT NOT NULL DEFAULT 'employee',
        hourly_rate REAL NOT NULL DEFAULT 0
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS work_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT,
        worked_seconds INTEGER DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    """)

    conn.commit()
    conn.close()


def add_or_update_user(telegram_id: int, full_name: str, username: Optional[str], is_admin: bool = False):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id, role FROM users WHERE telegram_id = ?", (telegram_id,))
    existing_user = cursor.fetchone()

    if existing_user:
        if is_admin and existing_user["role"] != "admin":
            cursor.execute("""
                UPDATE users
                SET full_name = ?, username = ?, role = 'admin'
                WHERE telegram_id = ?
            """, (full_name, username, telegram_id))
        else:
            cursor.execute("""
                UPDATE users
                SET full_name = ?, username = ?
                WHERE telegram_id = ?
            """, (full_name, username, telegram_id))
    else:
        role = "admin" if is_admin else "employee"
        cursor.execute("""
            INSERT INTO users (telegram_id, full_name, username, role)
            VALUES (?, ?, ?, ?)
        """, (telegram_id, full_name, username, role))

    conn.commit()
    conn.close()


def get_user_by_telegram_id(telegram_id: int) -> Optional[sqlite3.Row]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,))
    user = cursor.fetchone()

    conn.close()
    return user


def get_all_users() -> List[sqlite3.Row]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users ORDER BY full_name")
    users = cursor.fetchall()

    conn.close()
    return users


def set_hourly_rate(telegram_id: int, hourly_rate: float) -> bool:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("UPDATE users SET hourly_rate = ? WHERE telegram_id = ?", (hourly_rate, telegram_id))
    updated = cursor.rowcount

    conn.commit()
    conn.close()

    return updated > 0


def set_role(telegram_id: int, role: str) -> bool:
    if role not in ("employee", "admin"):
        return False

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("UPDATE users SET role = ? WHERE telegram_id = ?", (role, telegram_id))
    updated = cursor.rowcount

    conn.commit()
    conn.close()

    return updated > 0


def get_open_session(user_id: int) -> Optional[sqlite3.Row]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM work_sessions
        WHERE user_id = ? AND end_time IS NULL
        ORDER BY id DESC
        LIMIT 1
    """, (user_id,))
    session = cursor.fetchone()

    conn.close()
    return session


def start_work_session(user_id: int) -> bool:
    open_session = get_open_session(user_id)
    if open_session:
        return False

    conn = get_connection()
    cursor = conn.cursor()

    start_time = datetime.now().isoformat()
    cursor.execute("""
        INSERT INTO work_sessions (user_id, start_time)
        VALUES (?, ?)
    """, (user_id, start_time))

    conn.commit()
    conn.close()
    return True


def end_work_session(user_id: int):
    open_session = get_open_session(user_id)
    if not open_session:
        return None

    start_time = datetime.fromisoformat(open_session["start_time"])
    end_time = datetime.now()
    worked_seconds = int((end_time - start_time).total_seconds())

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE work_sessions
        SET end_time = ?, worked_seconds = ?
        WHERE id = ?
    """, (end_time.isoformat(), worked_seconds, open_session["id"]))

    conn.commit()
    conn.close()

    return {
        "worked_seconds": worked_seconds,
        "start_time": open_session["start_time"],
        "end_time": end_time.isoformat()
    }


def format_seconds(seconds: int) -> str:
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    return f"{hours} ч {minutes} мин"


def get_user_sessions(telegram_id: int) -> List[sqlite3.Row]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT ws.*, u.full_name, u.hourly_rate
        FROM work_sessions ws
        JOIN users u ON ws.user_id = u.id
        WHERE u.telegram_id = ?
        ORDER BY ws.start_time DESC
    """, (telegram_id,))

    sessions = cursor.fetchall()
    conn.close()
    return sessions


def get_user_stats(telegram_id: int) -> Dict[str, Any]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT u.full_name, u.hourly_rate, COUNT(ws.id) as total_sessions,
               COALESCE(SUM(ws.worked_seconds), 0) as total_seconds
        FROM users u
        LEFT JOIN work_sessions ws ON u.id = ws.user_id AND ws.end_time IS NOT NULL
        WHERE u.telegram_id = ?
        GROUP BY u.id
    """, (telegram_id,))

    result = cursor.fetchone()
    conn.close()

    if not result:
        return {}

    total_seconds = result["total_seconds"] or 0
    hourly_rate = result["hourly_rate"] or 0
    total_amount = (total_seconds / 3600) * hourly_rate

    return {
        "full_name": result["full_name"],
        "hourly_rate": hourly_rate,
        "total_sessions": result["total_sessions"],
        "total_seconds": total_seconds,
        "formatted_time": format_seconds(total_seconds),
        "total_amount": round(total_amount, 2)
    }


def get_user_stats_by_period(telegram_id: int, start_date: str, end_date: str) -> Dict[str, Any]:
    conn = get_connection()
    cursor = conn.cursor()

    start_dt = f"{start_date}T00:00:00"
    end_dt = f"{end_date}T23:59:59"

    cursor.execute("""
        SELECT u.full_name, u.hourly_rate,
               COUNT(ws.id) as total_sessions,
               COALESCE(SUM(ws.worked_seconds), 0) as total_seconds
        FROM users u
        LEFT JOIN work_sessions ws 
            ON u.id = ws.user_id
            AND ws.end_time IS NOT NULL
            AND ws.start_time BETWEEN ? AND ?
        WHERE u.telegram_id = ?
        GROUP BY u.id
    """, (start_dt, end_dt, telegram_id))

    result = cursor.fetchone()
    conn.close()

    if not result:
        return {}

    total_seconds = result["total_seconds"] or 0
    hourly_rate = result["hourly_rate"] or 0
    total_amount = (total_seconds / 3600) * hourly_rate

    return {
        "full_name": result["full_name"],
        "hourly_rate": hourly_rate,
        "total_sessions": result["total_sessions"],
        "total_seconds": total_seconds,
        "formatted_time": format_seconds(total_seconds),
        "total_amount": round(total_amount, 2),
        "start_date": start_date,
        "end_date": end_date
    }


def get_admin_daily_stats() -> List[sqlite3.Row]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            date(ws.start_time) as work_day,
            u.full_name,
            COUNT(ws.id) as sessions_count,
            COALESCE(SUM(ws.worked_seconds), 0) as total_seconds
        FROM work_sessions ws
        JOIN users u ON ws.user_id = u.id
        WHERE ws.end_time IS NOT NULL
        GROUP BY date(ws.start_time), u.full_name
        ORDER BY work_day DESC, u.full_name
    """)

    results = cursor.fetchall()
    conn.close()
    return results


def get_admin_all_workers_stats() -> List[sqlite3.Row]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            u.full_name,
            u.telegram_id,
            u.hourly_rate,
            COUNT(ws.id) as sessions_count,
            COALESCE(SUM(ws.worked_seconds), 0) as total_seconds
        FROM users u
        LEFT JOIN work_sessions ws ON u.id = ws.user_id AND ws.end_time IS NOT NULL
        GROUP BY u.id
        ORDER BY u.full_name
    """)

    results = cursor.fetchall()
    conn.close()
    return results