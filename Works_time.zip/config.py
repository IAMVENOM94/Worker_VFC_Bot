import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")

admin_ids_raw = os.getenv("ADMIN_IDS", "")
ADMIN_IDS = [
    int(admin_id.strip())
    for admin_id in admin_ids_raw.split(",")
    if admin_id.strip().isdigit()
]

if not BOT_TOKEN:
    raise ValueError("Не найден BOT_TOKEN в .env")