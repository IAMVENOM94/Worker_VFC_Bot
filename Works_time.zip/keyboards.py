from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


def get_main_keyboard(is_admin: bool = False):
    buttons = [
        [KeyboardButton(text="Начало работы")],
        [KeyboardButton(text="Конец работы")],
        [KeyboardButton(text="Моя статистика")],
        [KeyboardButton(text="Подсчёт за период")],
    ]

    if is_admin:
        buttons.extend([
            [KeyboardButton(text="Статистика сотрудников")],
            [KeyboardButton(text="Статистика по дням")],
        ])

    return ReplyKeyboardMarkup(
        keyboard=buttons,
        resize_keyboard=True
    )